const hostels = {
    Male: [
        'Boys Hostel A',
        'Boys Hostel B'
    ],
    Female: [
        'Girls Hostel A',
        'Girls Hostel B'
    ]
};

const studentRoleBtn = document.getElementById('studentRole');
const wardenRoleBtn = document.getElementById('wardenRole');
const studentSection = document.getElementById('studentSection');
const wardenSection = document.getElementById('wardenSection');

if (studentRoleBtn && wardenRoleBtn && studentSection && wardenSection) {
    studentRoleBtn.addEventListener('click', () => {
        studentRoleBtn.classList.add('active');
        wardenRoleBtn.classList.remove('active');
        studentSection.style.display = '';
        wardenSection.style.display = 'none';
        if (complainFormContainer) complainFormContainer.style.display = '';
    });
    wardenRoleBtn.addEventListener('click', () => {
        wardenRoleBtn.classList.add('active');
        studentRoleBtn.classList.remove('active');
        studentSection.style.display = 'none';
        wardenSection.style.display = '';
        if (complainFormContainer) complainFormContainer.style.display = 'none';
        // Always check login state and show login form or dashboard
        fetch('/requests').then(res => {
            const wardenLoginBox = document.getElementById('wardenLoginBox');
            const wardenDashboard = document.getElementById('wardenDashboard');
            if (res.status === 401) {
                if (wardenLoginBox) wardenLoginBox.style.display = '';
                if (wardenDashboard) wardenDashboard.style.display = 'none';
            } else {
                if (wardenLoginBox) wardenLoginBox.style.display = 'none';
                if (wardenDashboard) wardenDashboard.style.display = '';
                loadRequests();
            }
        });
    });
}

const genderSelect = document.getElementById('gender');
const hostelSelect = document.getElementById('hostel');

if (genderSelect && hostelSelect) {
    genderSelect.addEventListener('change', function() {
        const gender = this.value;
        hostelSelect.innerHTML = '<option value="">Select</option>';
        if (hostels[gender]) {
            hostels[gender].forEach(h => {
                const opt = document.createElement('option');
                opt.value = h;
                opt.textContent = h;
                hostelSelect.appendChild(opt);
            });
        }
    });
}

const studentForm = document.getElementById('studentForm');
if (studentForm && genderSelect && hostelSelect) {
    studentForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const data = {
            name: document.getElementById('name').value,
            reg: document.getElementById('reg').value,
            branch: document.getElementById('branch').value,
            gender: genderSelect.value,
            hostel: hostelSelect.value
        };
        const res = await fetch('/request', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (res.ok) {
            alert('Permission requested!');
            studentForm.reset();
            hostelSelect.innerHTML = '<option value="">Select Gender First</option>';
        } else {
            alert('Submission failed.');
        }
    });
}

async function loadRequests() {
    const res = await fetch('/requests');
    const requests = await res.json();
    const tbody = document.querySelector('#requestsTable tbody');
    tbody.innerHTML = '';
    requests.forEach(req => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${req.name}</td>
            <td>${req.reg}</td>
            <td>${req.branch}</td>
            <td>${req.gender}</td>
            <td>${req.hostel}</td>
            <td>${req.status || 'Pending'}</td>
            <td>${req.roomNo ? req.roomNo : (req.status === 'Approved' ? 'N/A' : `<input type='text' class='roomInput' data-id='${req.reg}' placeholder='Room No.' style='width:70px;'/>`)}</td>
            <td>${req.status === 'Approved' ? '' : `<button data-id="${req.reg}" class="assignBtn">Assign & Approve</button>`}</td>
        `;
        tbody.appendChild(tr);
    });
    // Add event listeners for assign buttons
    document.querySelectorAll('.assignBtn').forEach(btn => {
        btn.addEventListener('click', async function() {
            const reg = this.getAttribute('data-id');
            const input = document.querySelector(`.roomInput[data-id='${reg}']`);
            const roomNo = input ? input.value.trim() : '';
            if (!roomNo) {
                alert('Please enter a room number.');
                return;
            }
            const res = await fetch('/assign-room', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ reg, roomNo })
            });
            if (res.ok) {
                loadRequests();
            } else {
                alert('Assignment failed.');
            }
        });
    });
}

const wardenLoginBox = document.getElementById('wardenLoginBox');
const wardenDashboard = document.getElementById('wardenDashboard');
const wardenLoginForm = document.getElementById('wardenLoginForm');
const wardenLoginError = document.getElementById('wardenLoginError');
const wardenLogoutBtn = document.getElementById('wardenLogoutBtn');

if (wardenLoginForm) {
    wardenLoginForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const data = {
            username: document.getElementById('wardenUsername').value,
            password: document.getElementById('wardenPassword').value
        };
        const res = await fetch('/warden-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if (res.ok) {
            wardenLoginBox.style.display = 'none';
            wardenDashboard.style.display = '';
            wardenLoginError.style.display = 'none';
            loadRequests();
        } else {
            wardenLoginError.style.display = '';
        }
    });
}
if (wardenLogoutBtn) {
    wardenLogoutBtn.onclick = async function() {
        await fetch('/warden-logout', { method: 'POST' });
        wardenDashboard.style.display = 'none';
        wardenLoginBox.style.display = '';
    };
}
// Update role switch logic to reset warden section
wardenRoleBtn.addEventListener('click', () => {
    wardenRoleBtn.classList.add('active');
    studentRoleBtn.classList.remove('active');
    studentSection.style.display = 'none';
    wardenSection.style.display = '';
    // Check if already logged in
    fetch('/requests').then(res => {
        if (res.status === 401) {
            wardenLoginBox.style.display = '';
            wardenDashboard.style.display = 'none';
        } else {
            wardenLoginBox.style.display = 'none';
            wardenDashboard.style.display = '';
            loadRequests();
        }
    });
});

const viewComplaintsBtn = document.getElementById('viewComplaintsBtn');
const complaintsSection = document.getElementById('complaintsSection');
const complaintsTable = document.getElementById('complaintsTable');

if (viewComplaintsBtn) {
    viewComplaintsBtn.addEventListener('click', async function() {
        
        if (complaintsSection.style.display === 'none' || complaintsSection.style.display === '') {
            // Show and load complaints
            const res = await fetch('/complaints');
            if (res.ok) {
                const complaints = await res.json();
                const tbody = complaintsTable.querySelector('tbody');
                tbody.innerHTML = '';
                complaints.forEach(c => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${c.name}</td>
                        <td>${c.roll}</td>
                        <td>${c.hostel}</td>
                        <td>${c.room}</td>
                        <td>${c.text}</td>
                        <td>${new Date(c.date).toLocaleString()}</td>
                    `;
                    tbody.appendChild(tr);
                });
            }
            complaintsSection.style.display = 'block';
            viewComplaintsBtn.textContent = 'Hide Complaints';
        } else {
            // Hide complaints
            complaintsSection.style.display = 'none';
            viewComplaintsBtn.textContent = 'View Complaints';
        }
    });
}

const complainForm = document.getElementById('complainForm');
const complainFormContainer = document.getElementById('complainFormContainer');
if (complainForm) {
    complainForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const nameField = document.getElementById('complainName');
        const rollField = document.getElementById('complainRoll');
        const hostelField = document.getElementById('complainHostel');
        const roomField = document.getElementById('complainRoom');
        const textField = document.getElementById('complainText');
        if (!nameField || !rollField || !hostelField || !roomField || !textField) {
            alert("Complaint form is broken: some fields are missing. Please contact the developer.");
            return;
        }
        const data = {
            name: nameField.value,
            roll: rollField.value,
            hostel: hostelField.value,
            room: roomField.value,
            text: textField.value
        };
        const res = await fetch('/complain', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const msg = document.getElementById('complainMsg');
        if (res.ok) {
            msg.style.display = '';
            msg.style.color = 'green';
            msg.textContent = 'Complaint submitted successfully!';
            complainForm.reset();
            
            // Hide message after 3 seconds
            setTimeout(() => {
                msg.style.display = 'none';
            }, 3000);
        } else {
            msg.style.display = '';
            msg.style.color = 'red';
            msg.textContent = 'Failed to submit complaint.';
            
            // Hide message after 3 seconds
            setTimeout(() => {
                msg.style.display = 'none';
            }, 3000);
        }
    });
}

const checkStatusBtn = document.getElementById('checkStatusBtn');
const statusResult = document.getElementById('statusResult');
const statusDetails = document.getElementById('statusDetails');

if (checkStatusBtn) {
    checkStatusBtn.addEventListener('click', async function() {
        const regInput = document.getElementById('statusReg');
        const reg = regInput.value.trim();
        
        if (!reg) {
            alert('Please enter your registration number');
            return;
        }
        
        try {
            const res = await fetch(`/student-status/${reg}`);
            
            if (res.status === 404) {
                statusResult.style.display = '';
                statusResult.style.backgroundColor = '#ffcccc';
                statusDetails.innerHTML = '<p>No application found with this registration number. Please make sure you have submitted an application and entered the correct registration number.</p>';
                return;
            }
            
            if (!res.ok) {
                throw new Error('Failed to fetch status');
            }
            
            const data = await res.json();
            statusResult.style.display = '';
            
            if (data.status === 'Approved') {
                statusResult.style.backgroundColor = '#d4edda';
                let roomInfo = data.roomNo ? 
                    `<p><strong>Room Number:</strong> ${data.roomNo}</p>` : 
                    '<p><strong>Room Number:</strong> Not yet assigned</p>';
                
                statusDetails.innerHTML = `
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Registration Number:</strong> ${data.reg}</p>
                    <p><strong>Branch:</strong> ${data.branch}</p>
                    <p><strong>Hostel:</strong> ${data.hostel}</p>
                    <p><strong>Status:</strong> <span style="color:green;font-weight:bold;">APPROVED</span></p>
                    ${roomInfo}
                `;
            } else {
                statusResult.style.backgroundColor = '#fff3cd';
                statusDetails.innerHTML = `
                    <p><strong>Name:</strong> ${data.name}</p>
                    <p><strong>Registration Number:</strong> ${data.reg}</p>
                    <p><strong>Branch:</strong> ${data.branch}</p>
                    <p><strong>Hostel:</strong> ${data.hostel}</p>
                    <p><strong>Status:</strong> <span style="color:orange;font-weight:bold;">PENDING</span></p>
                    <p>Your application is still being processed. Please check back later.</p>
                `;
            }
        } catch (error) {
            console.error('Error:', error);
            statusResult.style.display = '';
            statusResult.style.backgroundColor = '#ffcccc';
            statusDetails.innerHTML = '<p>An error occurred while checking your status. Please try again later.</p>';
        }
    });
}