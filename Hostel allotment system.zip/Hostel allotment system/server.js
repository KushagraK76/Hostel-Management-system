const express = require('express');
const path = require('path');
const session = require('express-session');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));
app.use(session({
    secret: 'hostel-secret',
    resave: false,
    saveUninitialized: false
}));

const DATA_DIR = path.join(__dirname, 'data');
const REQUESTS_FILE = path.join(DATA_DIR, 'requests.json');
const COMPLAINTS_FILE = path.join(DATA_DIR, 'complaints.json');

if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR);
}

let requests = [
    {
        name: "Test Student",
        reg: "TEST123",
        branch: "Computer Science",
        gender: "Male",
        hostel: "Boys Hostel A",
        status: "Approved",
        roomNo: "A101"
    }
];
let complaints = [];

try {
    if (fs.existsSync(REQUESTS_FILE)) {
        requests = JSON.parse(fs.readFileSync(REQUESTS_FILE, 'utf8'));
    }
    if (fs.existsSync(COMPLAINTS_FILE)) {
        complaints = JSON.parse(fs.readFileSync(COMPLAINTS_FILE, 'utf8'));
    }
} catch (error) {
    console.error('Error loading data:', error);
}

function saveData() {
    try {
        fs.writeFileSync(REQUESTS_FILE, JSON.stringify(requests, null, 2));
        fs.writeFileSync(COMPLAINTS_FILE, JSON.stringify(complaints, null, 2));
    } catch (error) {
        console.error('Error saving data:', error);
    }
}

app.post('/warden-login', (req, res) => {
    const { username, password } = req.body;
    if (username === 'warden' && password === 'warden123') {
        req.session.warden = true;
        return res.json({ success: true });
    }
    res.status(401).json({ error: 'Invalid credentials' });
});

app.post('/warden-logout', (req, res) => {
    req.session.destroy(() => {
        res.json({ success: true });
    });
});

function requireWarden(req, res, next) {
    if (req.session.warden) return next();
    res.status(401).json({ error: 'Unauthorized' });
}

app.post('/request', (req, res) => {
    const { name, reg, branch, gender, hostel } = req.body;
    if (!name || !reg || !branch || !gender || !hostel) {
        return res.status(400).json({ error: 'All fields required' });
    }
    if (requests.some(r => r.reg === reg && r.status !== 'Rejected')) {
        return res.status(400).json({ error: 'Request already exists' });
    }
    requests.push({ name, reg, branch, gender, hostel, status: 'Pending' });
    saveData();
    res.json({ success: true });
});

app.get('/requests', requireWarden, (req, res) => {
    const sortedRequests = [...requests].sort((a, b) => a.name.localeCompare(b.name));
    res.json(sortedRequests);
});

app.post('/approve', requireWarden, (req, res) => {
    const { reg } = req.body;
    const reqIndex = requests.findIndex(r => r.reg === reg);
    if (reqIndex === -1) {
        return res.status(404).json({ error: 'Request not found' });
    }
    requests[reqIndex].status = 'Approved';
    saveData();
    res.json({ success: true });
});

app.post('/assign-room', requireWarden, (req, res) => {
    const { reg, roomNo } = req.body;
    const reqIndex = requests.findIndex(r => r.reg === reg);
    if (reqIndex === -1) {
        return res.status(404).json({ error: 'Request not found' });
    }
    requests[reqIndex].roomNo = roomNo;
    requests[reqIndex].status = 'Approved';
    saveData();
    res.json({ success: true });
});

app.post('/complain', (req, res) => {
    const { name, roll, hostel, room, text } = req.body;
    if (!name || !roll || !hostel || !room || !text) {
        return res.status(400).json({ error: 'All fields required' });
    }
    complaints.push({ name, roll, hostel, room, text, date: new Date().toISOString() });
    saveData();
    res.json({ success: true });
});

app.get('/complaints', requireWarden, (req, res) => {
    res.json(complaints);
});

app.get('/student-status/:reg', (req, res) => {
    const reg = req.params.reg;
    console.log("Looking for registration:", reg);
    console.log("Available requests:", requests.map(r => r.reg));
    
    const request = requests.find(r => r.reg === reg);
    if (!request) {
        console.log("No request found for:", reg);
        return res.status(404).json({ error: 'No application found with this registration number' });
    }
    console.log("Found request:", request);
    res.json(request);
});

app.get('/hostel-assignments', (req, res) => {
    const hostels = [
        'Boys Hostel A',
        'Boys Hostel B',
        'Girls Hostel A',
        'Girls Hostel B'
    ];
    const assignments = {};
    hostels.forEach(hostel => {
        assignments[hostel] = requests
            .filter(r => r.hostel === hostel && r.status === 'Approved' && r.roomNo)
            .map(r => r.name)
            .sort((a, b) => a.localeCompare(b));
    });
    res.json(assignments);
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});